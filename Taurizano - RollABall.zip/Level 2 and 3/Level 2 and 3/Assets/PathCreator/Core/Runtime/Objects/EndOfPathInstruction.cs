﻿namespace PathCreation {
	public enum EndOfPathInstruction {Loop, Reverse, Stop};
}
