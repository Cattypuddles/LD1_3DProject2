using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SimpleTimer : MonoBehaviour
{
    private GameController gameController;
    public int secondsLeft = 30;
    public bool takingAway = false;
    public GameObject textDisplay;
    public Collision collision;
    

    private void Awake()
    {
        gameController = GetComponentInParent<GameController>();
    }

    // Start is called before the first frame update
    public void Start()
    {
        textDisplay.GetComponent<Text>().text = "00:" + secondsLeft;
    }
  

    // Update is called once per frame
    public void Update()
    {
        if (takingAway == false && secondsLeft > 0)
        {
            StartCoroutine(TimerTake());
        }
        if (secondsLeft <= 0f)
        {
            gameController.StateUpdate(GameController.GameStates.GameLost);
            this.enabled = false;

        }
        
      

    }
   private void OnTriggerEnter(Collider other)
    {
         if(other.gameObject.tag == "Pick Up")
        {
            secondsLeft += 5;

            Destroy(other.gameObject);
        }
    }
    IEnumerator TimerTake()
    {
        takingAway = true;
        yield return new WaitForSeconds(1);
        secondsLeft -= 1;
            { }
        if (secondsLeft < 10f)
        {
            textDisplay.GetComponent<Text>().text = "00:0" + secondsLeft;
        }
        else
        {
            textDisplay.GetComponent<Text>().text = "00:" + secondsLeft;
        }
        takingAway = false;
        
    }
    
}







