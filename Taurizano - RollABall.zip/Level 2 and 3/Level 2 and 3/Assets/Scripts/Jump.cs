using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump : MonoBehaviour
{
  //  bool canJump = true;
  //  public float jumpForce = 50;
  //  public PlayerController PlayerController;

    // Update is called once per frame
 //   void Update()
 //   {
 //       if (Input.GetKey(KeyCode.Space))
 //       {
 //           jump();
 //       }
    }

//    void jump()
//    {
//        if (canJump)
//        {
//            canJump = false;
//            GetComponent<Rigidbody>().AddForce(this.gameObject.transform.up * jumpForce);
//        }
//    }

//    void OnCollisionEnter(Collision collision)
//    {
//        if (collision.gameObject.tag == "Ground")
//        {
//            canJump = true;
//        }
//    }
//}
